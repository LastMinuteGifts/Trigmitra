import { mathsTutorSystemPrompt } from './aiPrompt.js';
import { structuredSolutionSchema } from './solutionSchema.js';
export async function solveMathsImage(image, mimetype, config) {
    if (!config.apiKey) {
        throw new Error('AI_PROVIDER_NOT_CONFIGURED');
    }
    const response = await fetch(config.apiUrl, {
        method: 'POST',
        headers: { Authorization: `Bearer ${config.apiKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
            model: config.model,
            temperature: 0.1,
            response_format: { type: 'json_object' },
            messages: [
                { role: 'system', content: mathsTutorSystemPrompt },
                { role: 'user', content: [{ type: 'text', text: 'Analyze this Class 10 maths question image and return the required JSON.' }, { type: 'image_url', image_url: { url: `data:${mimetype};base64,${image.toString('base64')}` } }] },
            ],
        }),
    });
    if (!response.ok)
        throw new Error(`AI_PROVIDER_${response.status}`);
    const payload = await response.json();
    const content = payload.choices?.[0]?.message?.content;
    if (!content)
        throw new Error('AI_EMPTY_RESPONSE');
    return structuredSolutionSchema.parse(JSON.parse(content));
}
//# sourceMappingURL=aiClient.js.map